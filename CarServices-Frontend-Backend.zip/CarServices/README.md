# Car Services App
Recreated starter implementation based on the public AutoCare Pro deployment. This is not the original Bolt source code.

## Frontend
cd Frontend
npm install
npm run dev

## Backend
cd Backend
dotnet restore
dotnet run

Update Frontend/src/main.jsx API URL if the backend runs on a different port.
